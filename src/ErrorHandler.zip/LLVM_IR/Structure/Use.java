package LLVM_IR.Structure;

public class Use {
}
