package LLVM_IR.Structure;

public class BasicBlock {
}
