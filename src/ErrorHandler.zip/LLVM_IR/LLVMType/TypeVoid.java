package LLVM_IR.LLVMType;

public class TypeVoid extends Type {
    public TypeVoid() {

    }
    public String toString() {
        return "void";
    }
}
