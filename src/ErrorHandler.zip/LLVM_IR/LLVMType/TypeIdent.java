package LLVM_IR.LLVMType;

public class TypeIdent extends Type {

}
