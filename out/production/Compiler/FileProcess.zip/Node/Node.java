package Node;

public abstract class Node {
    public abstract void writeNode();
}
