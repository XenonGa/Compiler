package LLVM_IR.LLVMType;

public class Type {

}
