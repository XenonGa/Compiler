package Node;

public enum StmtType {
    LVal_Assign_Exp,
    Exp,
    Block,
    If,
    For,
    Break,
    Continue,
    Return,
    LVal_Assign_Getint,
    Printf
}
